<?php

class PluginEvent extends \LimeSurvey\PluginManager\PluginEvent
{
    
}
