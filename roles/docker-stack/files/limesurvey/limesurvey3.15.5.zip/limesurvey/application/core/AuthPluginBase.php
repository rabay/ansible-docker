<?php

class AuthPluginBase extends \LimeSurvey\PluginManager\AuthPluginBase
{

}