<div id='Position' class='form-group'>
    <label class="col-sm-4 control-label" for='pos'><?php eT("Position:"); ?></label>
    <div class="col-sm-8 text-error">
        <?php eT('Unknown view!'); ?>
    </div>
</div>
