[![2amigOS!](http://yiiwheels.2amigos.us/images/logo-navbar.png)](http://www.2amigos.us)
=========  
[![Latest Stable Version](https://poser.pugx.org/2amigos/yiiwheels/v/stable.svg)](https://packagist.org/packages/2amigos/yiiwheels) [![Total Downloads](https://poser.pugx.org/2amigos/yiiwheels/downloads.svg)](https://packagist.org/packages/2amigos/yii2-editable-widget) [![Latest Unstable Version](https://poser.pugx.org/2amigos/yiiwheels/v/unstable.svg)](https://packagist.org/packages/2amigos/yiiwheels) [![License](https://poser.pugx.org/2amigos/yiiwheels/license.svg)](https://packagist.org/packages/2amigos/yiiwheels)

Yii Wheels (or Wheels) is an extended library for the [YiiStrap](http://getyiistrap.com) extension.

Please, visit [YiiWheels](http://yiiwheels.2amigos.us) site for further documentation of its use.

> [![2amigOS!](http://www.gravatar.com/avatar/55363394d72945ff7ed312556ec041e0.png)](http://www.2amigos.us)    
<i>web development has never been so fun</i>  
[www.2amigos.us](http://www.2amigos.us)
